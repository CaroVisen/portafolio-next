"use strict";
exports.id = 362;
exports.ids = [362];
exports.modules = {

/***/ 362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ projects)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./src/assets/webcovid2.png
/* harmony default export */ const webcovid2 = ({"src":"/_next/static/media/webcovid2.a563d34b.png","height":768,"width":1366,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAb0lEQVR42gFkAJv/APLy8sHCwMfHxcbKy8HFx93d3Onq6fn6+QD3+fm3rrSTbX6he4PUt67FyMp3b3Tq6usA9PTzwL/KlpWupo2YyLGy2+Dc3+jb8PLwAPPz8+nq6e3t7Ons7Ovu8Nfa1bjGuu/x8NztTYxBYf3NAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./src/pages/components/projects.tsx



const Projets = ({})=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            backgroundColor: "#171718",
            minHeight: "90vh",
            marginTop: "2%"
        },
        id: "projects",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                style: {
                    color: "#fff",
                    textAlign: "center"
                },
                children: "Proyectos"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    display: "flex",
                    color: "#47D16E",
                    textAlign: "center",
                    justifyContent: "space-around"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        display: "flex",
                        marginTop: "3%"
                    },
                    className: "carrousel",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "cardAbilitie",
                        style: {
                            width: "450px"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: webcovid2.src,
                                style: {
                                    width: "90%",
                                    margin: "5%",
                                    borderRadius: "25px"
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                style: {
                                    color: "#fff",
                                    textAlign: "center",
                                    fontSize: "1.5em",
                                    marginBottom: "3%"
                                },
                                children: [
                                    "Web Covid",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "HTML - CSS - JavaScript"
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const projects = (Projets);


/***/ })

};
;