import React from "react";

const Projets = ({

}) => {
    return (
        <div style={{ backgroundColor: '#171718', minHeight: '50vh' }} id='projects'>
            <h1 style={{ color: '#fff', textAlign: 'center', }}>Proyectos</h1>
            <div style={{ display: 'flex', color: '#47D16E', textAlign: 'center' }}>
                <h1 style={{ textAlign: 'center', margin: 'auto', paddingTop: '5%' }}>Proximamente</h1>
                {/* <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT4Yi6ldcrjUYSo6uGOyBjp1lupyD6kPW59CA&usqp=CAU" style={{ borderRadius: '25px', height: '30vh', border: '3px solid #47D16E' }} className='cardProject' /> */}
            </div>
        </div>

    )
}

export default Projets;